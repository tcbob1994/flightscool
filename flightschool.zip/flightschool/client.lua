ESX = nil
local SetupComplete = false
local PlayerLoaded = false
local showPlanePos = false
local veh = nil
local inVehicle = false
local started = false
local vehPlate = nil
local lastpostion = 1
local Coords = { }
Coords = {
	{x = -1284.247, y = -2184.803, z = 14.126,h =  57.98},
	{x = -1354.234, y = -2242.154, z = 14.125,h =  150.093},
	{x = -1484.067, y = -2466.833, z = 14.259, h = 149.465},
	{x = -1771.191, y = -2962.082, z = 31.77,h =  152.728},
	{x = -2175.036, y = -3679.347, z = 109.166,h =  150.46},
	{x = -2319.242, y = -3955.157, z = 154.015,h =  151.946},
	{x = -2537.601, y = -4439.864, z = 237.826,h =  161.937},
	{x = -2624.051, y = -4776.777, z = 293.014,h =  172.752},
	{x = -2644.212, y = -4960.259, z = 306.778,h =  179.338},
	{x = -2497.944, y = -5778.929, z = 331.46,h =  203.797},
	{x = -2400.839, y = -5992.615, z = 340.537,h =  209.474},
	{x = -2228.806, y = -6273.159, z = 345.966,h =  216.442},
	{x = -1992.976, y = -6549.808, z = 349.992,h =  226.435},
	{x = -1801.499, y = -6712.296, z = 349.957,h =  233.993},
	{x = -1665.901, y = -6806.687, z = 347.476,h =  237.346},
	{x = -1445.337, y = -6942.902, z = 340.803,h =  238.503},
	{x = -583.676, y = -7399.74, z = 404.51,h =  244.042},
	{x = -12.672, y = -7649.907, z = 457.001,h =  249.817},
	{x = 176.011, y = -7714.288, z = 420.976,h =  257.294},
	{x = 469.942, y = -7765.015, z = 410.527,h =  267.886},
	{x = 667.288, y = -7761.604, z = 405.06,h =  278.297},
	{x = 1419.314, y = -7410.503, z = 352.413,h =  317.297},
	{x = 1592.219, y = -7197.506, z = 324.925,h =  329.092},
	{x = 1700.845, y = -6987.158, z = 298.126,h =  339.022},
	{x = 1800.68, y = -6683.145, z = 304.634,h =  348.1},
	{x = 1872.692, y = -6409.051, z = 342.352,h =  351.055},
	{x = 1902.463, y = -6120.962, z = 298.822,h =  359.209},
	{x = 1886.844, y = -5822.281, z = 243.382,h =  7.958},
	{x = 1823.091, y = -5449.473, z = 200.189,h =  11.991},
	{x = 1728.491, y = -5085.584, z = 185.764,h =  22.554},
	{x = 1634.143, y = -4880.969, z = 186.631,h =  31.848},
	{x = 1392.711, y = -4583.566, z = 134.345,h =  42.632},
	{x = 936.002, y = -4201.136, z = 145.121,h =  61.881},
	{x = 742.182, y = -4091.426, z = 100.297,h =  61.187},
	{x = 477.97, y = -3947.366, z = 88.532,h =  61.969},
	{x = -112.806, y = -3642.511, z = 52.216,h =  63.938},
	{x = -355.682, y = -3512.403, z = 42.738,h =  61.914},
	{x = -765.114, y = -3277.847, z = 31.019,h =  59.603},
	{x = -884.447, y = -3208.505, z = 20.01,h =  59.508},
	{x = -1020.273, y = -3131.121, z = 14.632,h =  59.726},
	{x = -1119.84, y = -3074.291, z = 13.983,h =  59.141},
	{x = -1181.255, y = -3038.458, z = 14.072,h =  60.179},
	{x = -1230.186, y = -3010.133, z = 14.062,h =  60.058},
	{x = -1271.843, y = -2986.063, z = 14.057,h =  59.973},
	{x = -1377.014, y = -2924.88, z = 14.068,h =  59.758},
	{x = -1453.221, y = -2882.716, z = 14.078,h =  77.146},
	{x = -1473.087, y = -2880.143, z = 14.083,h =  82.154},
	{x = -1502.259, y = -2896.741, z = 14.095,h =  151.865},
	{x = -1549.242, y = -2975.565, z = 14.087,h =  149.573},
	{x = -1653.116, y = -3142.895, z = 14.12,h =  152.511},
	{x = -1653.116, y = -3142.895, z = 14.12,h =  152.511},
}

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end
	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(100)
	end
	ESX.PlayerData = ESX.GetPlayerData()
	PlayerLoaded = true
end)

Citizen.CreateThread(function()
	while not SetupComplete do
		Citizen.Wait(100)
		if PlayerLoaded then
			ESX.TriggerServerCallback('flightschool:CheckNewVersion', function(isNewestVersion)
				if isNewestVersion then
					SetupComplete = true
				else
					SetupComplete = false
					ESX.ShowNotification(_U('need_setup'))
				end
			end)
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if PlayerLoaded then
			local x = -999.987
			local y = -2346.486
			local z = 13.925
			local range = 1.0
			DrawMarker( 1, x, y, z-1, 0, 0, 0, 0, 0, 0, range * 2, range * 2, 0.8001, 0, 191, 255, 165, 0, 0, 0, 0)
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if PlayerLoaded then
			local x = -999.987
			local y = -2346.486
			local z = 13.925
			local ped = GetPlayerPed(-1)
			local ppos = GetEntityCoords(ped)
			local distance = GetDistanceBetweenCoords(ppos, x, y, z, false)
			if distance <= 2.0 then
				ShowHelpNotification(_U('start_school'))
			end
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if PlayerLoaded then
			local x = -999.987
			local y = -2346.486
			local z = 13.925
			local ped = GetPlayerPed(-1)
			local ppos = GetEntityCoords(ped)
			local distance = GetDistanceBetweenCoords(ppos, x, y, z, false)
			if IsControlJustPressed(0, Config.key1) and distance <= 2.0 then
				TriggerEvent('flightschool:startFlight')
			end
		end
	end
end)

function ShowHelpNotification(text)
    ClearAllHelpMessages();
    SetTextComponentFormat("STRING");
    AddTextComponentString(text);
    DisplayHelpTextFromStringLabel(0, false, true, 5000);
end

RegisterNetEvent('flightschool:startFlight')
AddEventHandler('flightschool:startFlight', function()
	local x = -1118.11
	local y = -2296.27
	local z = 13.945
	local h = 56.781
	local ModelHash = 0x39D6779E -- this is the model for duster
	if not IsModelInCdimage(ModelHash) then return end
	RequestModel(ModelHash) -- Request the model
	while not HasModelLoaded(ModelHash) do -- Waits for the model to load with a check so it does not get stuck in an infinite loop
	  Citizen.Wait(10)
	end
	veh = CreateVehicle(ModelHash, x, y, z, h, true, false)
	vehPlate = GetVehicleNumberPlateText(veh)
	SetNewWaypoint(x,y)
	showPlanePos = true
	started = true
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if started then
			local vpos = GetEntityCoords(veh)
			local range = 10.0
			local ped = GetPlayerPed(-1)
			local ppos = GetEntityCoords(ped)
			local testVeh = GetVehiclePedIsIn(ped, false) -- Important to set it to false to test if the player is in the exact plane at the moment
			local testPlate = GetVehicleNumberPlateText(testVeh)
			inVehicle = IsPedInAnyPlane(ped)
			local distance = GetDistanceBetweenCoords(ppos, vpos.x, vpos.y, vpos.z, false)
			if showPlanePos then
				SetNewWaypoint(vpos.x,vpos.y)
				DrawMarker( 1, vpos.x, vpos.y, vpos.z-1, 0, 0, 0, 0, 0, 0, range * 2, range * 2, 0.8001, 0, 255, 191, 165, 0, 0, 0, 0)
				ESX.ShowNotification(_U('goto_plane'))
			end
			if inVehicle and testPlate == vehPlate then
				showPlanePos = false
				if lastpostion ~= nil and GetDistanceBetweenCoords(ppos, Coords[lastpostion].x,Coords[lastpostion].y,Coords[lastpostion].z, false) <= 10.0 then
					lastpostion = lastpostion + 1
					print('lastpostion: '..lastpostion)
				elseif GetDistanceBetweenCoords(ppos, Coords[lastpostion].x,Coords[lastpostion].y,Coords[lastpostion].z, false) >= 10.0 then
					if lastpostion <= 5 then
						SetNewWaypoint(Coords[lastpostion].x,Coords[lastpostion].y)
						DrawMarker( 1,Coords[lastpostion].x, Coords[lastpostion].y, Coords[lastpostion].z-1, 0, 0, 0, 0, 0, 0, range * 2, range * 2, 1.0, 255, 0, 23, 165, 0, 0, 0, 0)
					elseif lastpostion >= 71 then
						SetNewWaypoint(Coords[lastpostion].x,Coords[lastpostion].y)
						DrawMarker( 1,Coords[lastpostion].x, Coords[lastpostion].y, Coords[lastpostion].z-1, 0, 0, 0, 0, 0, 0, range * 2, range * 2, 1.0, 255, 0, 23, 165, 0, 0, 0, 0)
					else
						SetNewWaypoint(Coords[lastpostion].x,Coords[lastpostion].y)
						DrawMarker( 6,Coords[lastpostion].x, Coords[lastpostion].y, Coords[lastpostion].z-1, 0, 0, 0, 0, 0, 0, range * 2 , range * 2, range * 2, 255, 0, 23, 165, 0, 1, 0, 0)
					end
				end
			elseif not inVehicle and not showPlanePos then
				showPlanePos = true
			elseif inVehicle and testPlate ~= vehPlate then
				ESX.ShowNotification('That is not the intended Plane')
				showPlanePos = true
			end
			if lastpostion == 1 then
			ESX.ShowNotification('Drive The Plane to the starting Point')
			elseif lastpostion == 2 then
			ESX.ShowNotification('Drive The Plane to the next Point')
			elseif lastpostion == 3 then
			ESX.ShowNotification('Accelerate slowly')
			elseif lastpostion == 4 then
			ESX.ShowNotification('Accelerate faster')
			elseif lastpostion == 5 then
			ESX.ShowNotification('Ready to take off')
			elseif lastpostion == 50 then
			ESX.ShowNotification('Land the Plane on the field')
			elseif lastpostion == 51 then
			ESX.ShowNotification('Land the Plane on the field')
			elseif lastpostion == 52 then
			ESX.ShowNotification('Land the Plane on the field')
			elseif lastpostion == 53 then
			ESX.ShowNotification('Land the Plane on the field')
			elseif lastpostion == 59 then
			ESX.ShowNotification('Good Work!')
			elseif lastpostion == 60 then
			ESX.ShowNotification('Drive The Plane to the next Point')
			elseif lastpostion == 61 then
			ESX.ShowNotification('Drive The Plane to the next Point')
			elseif lastpostion == 62 then
			ESX.ShowNotification('Drive The Plane to the next Point')
			elseif lastpostion == 69 then
			Wait(1000)
			ESX.ShowNotification('~r~STOP~r~ Be aware of other Planes!')
			elseif lastpostion == 70 then
			ESX.ShowNotification('Drive The Plane into the hangar')
			elseif lastpostion == 50 then
			ESX.ShowNotification('Congratulation, you have ~g~passed~g~ the test')
			Wait(1000)
			DeleteVehicle(veh)
			break;
			else
			ESX.ShowNotification('Fly The Plane to the next Point')
			end
		end
	end
end)