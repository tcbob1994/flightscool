Config = {}
--[[
	LOCALE SETTINGS
--]]

Config.Locale = 'de' -- de, en for now

-- !!!DISCLAIMER!!!
-- Locales are translated from engish to other languages!
-- feel free to edit them as you like if you like to have your language in write it to me and i add them

--[[
	Key Configuration
--]]

Config.key1 = 46

--[[
	CONFIGURATION MAIN SETTINGS
--]]

