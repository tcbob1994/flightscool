Locales['en'] = {
	['need_setup'] = '~r~FLIGHT SCHOOL:~r~ ~w~Update Needed~w~',
	['start_setup'] = 'Setup is started...',
	['end_setup'] = 'setup completed',
	['failed_setup'] = 'Setup failed',
	['start_school'] = 'Push ~INPUT_PICKUP~ to start your test flight.',
	['goto_plane'] = 'Go to your Plane!'
}

