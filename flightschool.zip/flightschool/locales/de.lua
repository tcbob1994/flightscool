Locales['de'] = {
	['need_setup'] = '~r~FLIGHT SCHOOL:~r~ ~w~Update Benötigt~w~',
	['start_setup'] = 'Setup wird gestartet...',
	['end_setup'] = 'Setup abgeschlossen',
	['failed_setup'] = 'Setup fehlgeschlagen',
	['start_school'] = 'Drücke ~INPUT_PICKUP~ um einen Flugschein zu machen.',
	['goto_plane'] = 'Gehe zum Flugzeug!'
}