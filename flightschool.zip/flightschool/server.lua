ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
local CurrentVersion = '1.1'
local isUptoDate = false

PerformHttpRequest("https://raw.githubusercontent.com/tcbob1994/flightscool/main/VERSION.md", function(Error, NewVersion, Header)
	if CurrentVersion ~= NewVersion and tonumber(CurrentVersion) < tonumber(NewVersion) then
		print("\n")
		print("####")
		print("#### FLIGHT SCHOOL")
		print("####")
		print("#### ^4Current Version: " .. CurrentVersion .. "^4")
		print("#### ^5Newest Version: " .. NewVersion .. "^5")
		print("####")
		print("#### ^4Outdated^4, please download the newest Version!")
		print("####")
		print("\n")
		isUptoDate = false
	else
		print("\n")
		print("####")
		print("#### FLIGHT SCHOOL")
		print("####")
		print("#### ^4Current Version: " .. CurrentVersion .. "^4")
		print("#### ^5Newest Version: " .. NewVersion .. "^5")
		print("####")
		print("#### ^4Everything is Up to date! ^4")
		print("####")
		print("\n")
		isUptoDate = true
	end
end)

ESX.RegisterServerCallback('flightschool:CheckNewVersion', function(source, cb)
	cb(isUptoDate)
end)