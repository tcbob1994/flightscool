# bob_flightschool
 ESX Flight School Version 1.0

You are able to park your vehicle anywhere you like it doesnt matter on wich position.
The vehicle stays there until you unpark it even if the server restarts.

## Features:
* Flight School

## Installation

* add ensure flightschool to your server.cfg

## Recommended Resources for the best results: // if you know what you are doing they are Optional
* progressBars